rm -r bin;
mkdir bin;
`javac -sourcepath "/root/ProjetBdd/src" -cp "/root/dist/*" -d "/root/ProjetBdd/bin" "/root/ProjetBdd/src/main/Main.java"`;

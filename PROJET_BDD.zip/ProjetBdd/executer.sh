#!/bin/bash
cd /root/ProjetBdd/bin/;
cd ..;
`java -cp "/root/ProjetBdd/bin/:/root/dist/lib/*" main.Main`;
